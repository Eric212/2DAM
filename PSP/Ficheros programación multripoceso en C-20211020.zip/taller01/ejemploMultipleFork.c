#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

void main(void) {  
  
   
	fork();
   
	
	fork();
   
	
	fork();
	
  
	printf("Hola peña!\n");
    
  
	exit(0);
}
