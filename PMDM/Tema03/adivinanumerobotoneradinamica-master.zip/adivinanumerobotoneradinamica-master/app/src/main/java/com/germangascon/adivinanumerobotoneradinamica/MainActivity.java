package com.germangascon.adivinanumerobotoneradinamica;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private final int MIN = 1;
    private final int MAX = 10;
    private final int INTENTOS = 3;

    private final int ROWS = 2;
    private final int COLS = 5;

    private int numero;
    private int intentos;
    private TextView tvIntentos;
    private TextView tvNumero;
    private TextView tvFeedback;
    private Button[][] buttons;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvIntentos = findViewById(R.id.tvIntentos);
        tvNumero = findViewById(R.id.tvNumero);
        tvFeedback = findViewById(R.id.tvFeedback);

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v instanceof Button) {
                    if(intentos > 0) {
                        v.setEnabled(false);
                        int apuesta = -1;
                        try {
                            apuesta = Integer.parseInt(((Button)v).getText().toString());
                            if (apuesta >= MIN && apuesta <= MAX) {
                                intentos--;
                                tvIntentos.setText("Quedan " + intentos + " intentos");
                                if(apuesta < numero) {
                                    tvFeedback.setText("El número es mayor");
                                    if(intentos == 0) {
                                        hasPerdido();
                                    }
                                } else if(apuesta > numero) {
                                    tvFeedback.setText("El número es menor");
                                    if(intentos == 0) {
                                        hasPerdido();
                                    }
                                } else {
                                    hasGanado();
                                }
                            }
                        } catch (NumberFormatException e) {
                            Toast.makeText(MainActivity.this, "Solo números!!", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        nuevaPartida();
                    }
                }
            }
        };

        TableLayout tlBotonera = findViewById(R.id.tlBotonera);
        buttons = new Button[ROWS][COLS];
        int cont = 1;
        for(int i = 0; i < ROWS; i++) {
            for(int j = 0; j < COLS; j++) {
                buttons[i][j] = new Button(this);
                buttons[i][j].setText(String.valueOf(cont));
                buttons[i][j].setOnClickListener(listener);
                cont++;
            }
        }

        TableRow.LayoutParams layoutParams = new TableRow.LayoutParams(
                TableRow.LayoutParams.WRAP_CONTENT,
                TableRow.LayoutParams.WRAP_CONTENT,
                1.0f);
        for(int i = 0; i < ROWS; i++) {
            TableRow tableRow = new TableRow(this);
            TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
            tableRow.setLayoutParams(lp);
            tlBotonera.addView(tableRow);
            for(int j = 0; j < COLS; j++) {
                buttons[i][j].setLayoutParams(layoutParams);
                tableRow.addView(buttons[i][j]);
            }
        }
        nuevaPartida();
    }

    private void nuevaPartida() {
        numero = aleatorio(MIN,MAX);
        intentos = INTENTOS;
        tvIntentos.setText("Quedan " + intentos + " intentos");
        tvNumero.setText("?");
        tvNumero.setTextColor(Color.parseColor("#0000FF"));
        tvFeedback.setText("");
        resetButtons();
    }

    private void resetButtons() {
        for(int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                buttons[i][j].setEnabled(true);
            }
        }
    }

    private void hasPerdido() {
        tvFeedback.setText("Has perdido.\nPulsa cualquier botón para continuar");
        tvNumero.setText(String.valueOf(numero));
        tvNumero.setTextColor(Color.parseColor("#FF0000"));
        Toast.makeText(this, "Has perdido", Toast.LENGTH_SHORT).show();
    }

    private void hasGanado() {
        intentos = 0;
        tvFeedback.setText("Acertaste!!\nPulsa cualquier botón para continuar");
        tvNumero.setText(String.valueOf(numero));
        tvNumero.setTextColor(Color.parseColor("#0000FF"));
        Toast.makeText(this, "Has ganado!!", Toast.LENGTH_SHORT).show();
    }

    private int aleatorio(int min, int max) {
        if (min >= max) {
            throw new IllegalArgumentException("El segundo número debe ser más grande que el primero");
        }
        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }
}