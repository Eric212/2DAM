package com.germangascon.adivinanumerotexto;

import android.graphics.Color;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private final int MIN = 1;
    private final int MAX = 10;
    private final int NINTENTOS = 3;
    private int nIntentos = NINTENTOS;
    private Button bJugar;
    private TextView tvIntentos;
    private TextView tvNumero;
    private TextView tvFeedback;
    private EditText etNumero;

    private int numero;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bJugar = findViewById(R.id.bJugar);
        tvIntentos = findViewById(R.id.tvIntentos);
        tvNumero = findViewById(R.id.tvNumero);
        tvFeedback = findViewById(R.id.tvFeedback);
        etNumero = findViewById(R.id.etNumero);

        bJugar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(nIntentos > 0) {
                    int apuesta = -1;
                    try {
                        apuesta = Integer.parseInt(etNumero.getText().toString());
                        if (apuesta >= MIN && apuesta <= MAX) {
                            nIntentos--;
                            tvIntentos.setText("Quedan " + nIntentos + " intentos");
                            if(apuesta < numero) {
                                tvFeedback.setText("El número es mayor");
                                if(nIntentos == 0) {
                                    hasPerdido();
                                }
                            } else if(apuesta > numero) {
                                tvFeedback.setText("El número es menor");
                                if(nIntentos == 0) {
                                    hasPerdido();
                                }
                            } else {
                                hasGanado();
                            }
                        }
                    } catch (NumberFormatException e) {
                        Toast.makeText(MainActivity.this, "Solo números!!", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    nuevaPartida();
                }
            }
        });
        nuevaPartida();
    }

    private void nuevaPartida() {
        numero = aleatorio(MIN,MAX);
        nIntentos = 3;
        tvIntentos.setText("Quedan " + nIntentos + " intentos");
        tvNumero.setText("?");
        tvNumero.setTextColor(Color.parseColor("#0000FF"));
        tvFeedback.setText("");
        etNumero.setText("");
        bJugar.setText("Jugar");
    }

    private void hasPerdido() {
        tvNumero.setText(String.valueOf(numero));
        tvNumero.setTextColor(Color.parseColor("#FF0000"));
        Toast.makeText(this, "Has perdido", Toast.LENGTH_SHORT).show();
        bJugar.setText("Nueva Partida");
    }

    private void hasGanado() {
        nIntentos = 0;
        tvFeedback.setText("Acertaste!!");
        tvNumero.setText(String.valueOf(numero));
        tvNumero.setTextColor(Color.parseColor("#0000FF"));
        Toast.makeText(this, "Has ganado!!", Toast.LENGTH_SHORT).show();
        bJugar.setText("Nueva Partida");
    }


    private int aleatorio(int min, int max) {
        if (min >= max) {
            throw new IllegalArgumentException("El segundo número debe ser más grande que el primero");
        }
        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }
}
