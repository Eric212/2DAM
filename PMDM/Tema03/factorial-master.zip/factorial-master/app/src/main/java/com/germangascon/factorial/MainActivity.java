package com.germangascon.factorial;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText etNumero;
    private Button bCalcula;
    private TextView tvFactorial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNumero = (EditText)findViewById(R.id.etNumero);
        bCalcula = (Button)findViewById(R.id.bCalcula);
        tvFactorial = (TextView)findViewById(R.id.tvFactorial);

        bCalcula.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int numero;
                long fac;
                try {
                    numero = Integer.parseInt(etNumero.getText().toString());
                    if(numero >= 0) {
                        fac = factorial(numero);
                        tvFactorial.setText(String.valueOf(fac));
                    } else {
                        Toast.makeText(MainActivity.this, "Sólo valores numéricos positivos", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this, "Sólo valores numéricos positivos", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private long factorial(int n) {
        long resultado = 1;
        while (n != 0) {
            resultado = resultado * n;
            n--;
        }
        return resultado;
    }

}
