package com.germangascon.pedrapapertisores;

import java.util.Random;

public class Lib {
    public static int aleatorio(int min, int max) {
        if (min >= max) {
            throw new IllegalArgumentException("max debe ser más grande que min");
        }
        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }
}
