package com.germangascon.pedrapapertisores;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
   public enum Juego {
      PIEDRA,
      PAPEL,
      TIJERA;

      public static Juego fromInteger(int x) {
         switch (x) {
            case 0:
               return PIEDRA;
            case 1:
               return PAPEL;
            case 2:
               return TIJERA;
         }
         return null;
      }
   }

   private ImageView ivResultado;
   private TextView tvFeedback;
   private ImageButton ibPiedra;
   private ImageButton ibPapel;
   private ImageButton ibTijera;
   private Juego juego;

   @Override
   protected void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.activity_main);

      ivResultado = findViewById(R.id.ivResultado);
      tvFeedback = findViewById(R.id.tvFeedback);
      ibPiedra = findViewById(R.id.ibPiedra);
      ibPapel = findViewById(R.id.ibPapel);
      ibTijera = findViewById(R.id.ibTijera);

      View.OnClickListener listener = new View.OnClickListener() {
         @Override
         public void onClick(View view) {
            int id = view.getId();
            nuevaPartida();
            switch (id) {
               case R.id.ibPiedra:
                  if(juego == Juego.TIJERA) {
                     hasGanado();
                  } else if (juego == Juego.PIEDRA){
                     empate();
                  } else {
                     hasPerdido();
                  }
                  break;
               case R.id.ibPapel:
                  if(juego == Juego.PIEDRA) {
                     hasGanado();
                  } else if (juego == Juego.PAPEL){
                     empate();
                  } else {
                     hasPerdido();
                  }
                  break;

               case R.id.ibTijera:
                  if(juego == Juego.PAPEL) {
                     hasGanado();
                  } else if (juego == Juego.TIJERA){
                     empate();
                  } else {
                     hasPerdido();
                  }
                  break;
            }
         }
      };

      ibPiedra.setOnClickListener(listener);
      ibPapel.setOnClickListener(listener);
      ibTijera.setOnClickListener(listener);
   }

   private void nuevaPartida() {
      juego = Juego.fromInteger(Lib.aleatorio(0,2));
      switch (juego) {
         case PIEDRA:
            ivResultado.setImageResource(R.drawable.pedra);
            break;
         case PAPEL:
            ivResultado.setImageResource(R.drawable.paper);
            break;
         case TIJERA:
            ivResultado.setImageResource(R.drawable.tisores);
            break;
      }
   }

   private void hasGanado() {
      tvFeedback.setText("Has ganado!!!");
   }

   private void hasPerdido() {
      tvFeedback.setText("Has perdido :(");
   }

   private void empate() {
      tvFeedback.setText("Empate");
   }
}
