package com.germangascon.caracreu;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    public enum Moneda {
        CARA,
        CRUZ;

        public static Moneda lanzar() {
            int x = aleatorio(0, 1);
            if(x % 2 == 0) {
                return CARA;
            } else {
                return CRUZ;
            }
        }

        private static int aleatorio(int min, int max) {
            if (min >= max) {
                throw new IllegalArgumentException("max debe ser más grande que min");
            }
            Random r = new Random();
            return r.nextInt((max - min) + 1) + min;
        }
    }
    private Button bCara;
    private Button bCruz;
    private TextView tvFeedback;
    private ImageView ivResultado;
    private Moneda moneda;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bCara = findViewById(R.id.bCara);
        bCruz = findViewById(R.id.bCruz);
        ivResultado = findViewById(R.id.ivResultado);
        tvFeedback = findViewById(R.id.tvFeedback);


        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = view.getId();
                nuevaPartida();
                if((id == R.id.bCara && moneda == Moneda.CARA) ||
                   (id == R.id.bCruz && moneda == Moneda.CRUZ)) {
                    tvFeedback.setText("Has guanyat!!");
                } else {
                    tvFeedback.setText("Has perdut :(");
                }
            }
        };

        bCara.setOnClickListener(listener);
        bCruz.setOnClickListener(listener);
    }

    private void nuevaPartida() {
        moneda = Moneda.lanzar();
        switch (moneda) {
            case CARA:
                ivResultado.setImageResource(R.drawable.euro_cara);
                break;
            case CRUZ:
                ivResultado.setImageResource(R.drawable.euro_cruz);
                break;
        }
    }


}
